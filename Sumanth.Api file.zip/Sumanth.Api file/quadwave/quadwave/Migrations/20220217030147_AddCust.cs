﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace quadwave.Migrations
{
    public partial class AddCust : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("Insert into CustomerDetails values('Nithin' ,'gowda','02/2/2000 15:20:10')");
            migrationBuilder.Sql("Insert into CustomerDetails values('manoj' ,'gowda','5/12/2000  18:20:00')");
            migrationBuilder.Sql("Insert into CustomerDetails values('Ajith' ,'Tech','8/18/2000  5:21:10')");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
