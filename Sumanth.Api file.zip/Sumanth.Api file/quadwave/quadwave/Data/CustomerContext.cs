﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using quadwave.Model;

namespace quadwave
{
    public class CustomerContext:DbContext
    {
        public CustomerContext(DbContextOptions<CustomerContext> opt) :base(opt)
        {

        }

        public DbSet<Customer> CustomerDetails { set; get; }

        public DbSet<CustomerAddress> CustomerAddressDetails { set; get; }
    }
}
