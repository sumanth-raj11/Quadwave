﻿using quadwave.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace quadwave.Data
{
    public class CustomerInfo : ICustomerInfo
    {
        private readonly CustomerContext _context;

        public CustomerInfo(CustomerContext context)
        {
            _context = context;
        }
        public Customer CreateCustomer(Customer C)
        {
            _context.CustomerDetails.Add(C);
            _context.SaveChanges();
            return C;
        }

        public void DeleteCustomer(Customer C)
        {
            _context.Remove(C);
            _context.SaveChanges();
        }

        public List<CustomerAddress> GetAddress()
        {
            var Customer = _context.CustomerAddressDetails.ToList();
            return Customer;
        }

        public Customer GetCustomer(int id)
        {
            var cust = _context.CustomerDetails.SingleOrDefault(m => m.CustomerId == id);
            return cust;
        }

       

        public List<Customer> GetCustomers()
        {
           var customer = _context.CustomerDetails.ToList();
            return customer;
        }

        public void UpdateCustomer(Customer c)
        {
             _context.CustomerDetails.Add(c);
             _context.SaveChanges();
            
        }


        //addresss

        public List<CustomerAddress> GetCustomerAddress()
        {
            var customer = _context.CustomerAddressDetails.ToList();
            return customer;
        }
    }
}
