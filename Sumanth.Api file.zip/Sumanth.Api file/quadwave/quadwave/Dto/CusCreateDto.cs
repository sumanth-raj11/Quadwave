﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace quadwave.Dto
{
    public class CusCreateDto
    {
        public string FirstName { set; get; }

        public string LastName { set; get; }

        public DateTime CreatedDate { set; get; }
    }
}
