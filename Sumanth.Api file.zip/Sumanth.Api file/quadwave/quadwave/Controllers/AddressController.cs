﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using quadwave.Data;
using quadwave.Dto;
    

namespace quadwave.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AddressController : ControllerBase
    {
        private readonly ICustomerInfo _info;
        private readonly IMapper _mapper;

        public AddressController(ICustomerInfo info, IMapper mapper)
        {
            _info = info;
            _mapper = mapper;
        }

        [HttpGet]
        public ActionResult<IEnumerable<AddressRdDto>> GetAddress()
        {
            var addr = _info.GetAddress();
            return Ok(_mapper.Map<IEnumerable<AddressRdDto>>(addr));
       
        }
    }

    
}
